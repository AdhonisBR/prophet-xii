// SPDX-License-Identifier: GPL-3.0-or-later
// PROPHET-XII DSP Kernel — Curtis CEM3320 4-Pole OTA Cascade ZDF/TPT Filter
// Mathematical grounding:
// - Vadim Zavalishin, "The Art of VA Filter Design" (https://noisehack.com/research/VAFilterDesign_1.0.3.pdf)
// - Surge XT sst-filters (https://github.com/surge-synthesizer/sst-filters)
// - Sequential Circuits Prophet-5/10 Rev3 CEM3320 topology with 5 Hz AC-coupled feedback loop

use core::f32::consts::PI;

/// Fast and accurate Padé rational approximation of `tanh(x)` for real-time audio saturation,
/// with exact saturation asymptotes `+/- 1.0` for `|x| >= 3.2`.
#[inline(always)]
pub fn fast_tanh(x: f32) -> f32 {
    let xc = x.clamp(-3.5, 3.5);
    let x2 = xc * xc;
    xc * (27.0 + x2) / (27.0 + 9.0 * x2)
}

/// Derivative `sech^2(x) = 1 - tanh^2(x)` for Newton-Raphson ZDF iteration.
#[inline(always)]
pub fn fast_sech2(x: f32) -> f32 {
    let t = fast_tanh(x);
    (1.0 - t * t).max(1.0e-5)
}

/// Curtis CEM3320 4-Pole Low-Pass ZDF/TPT Filter (Prophet-10 Rev3 Authentic Mode).
#[repr(C, align(32))]
#[derive(Clone, Debug)]
pub struct Cem3320Filter {
    /// Integrator states s1..s4 of the 4 cascaded OTA poles
    pub s: [f32; 4],
    /// State of the 5 Hz high-pass DC-blocking capacitor in the CEM3320 resonance loop
    pub dc_block_state: f32,
    pub sample_rate: f32,
    pub cutoff_hz: f32,
    pub resonance: f32,
    pub drive: f32,
    /// Per-voice cutoff tolerance multiplier (e.g. 0.98 ..= 1.02)
    pub cutoff_dispersion: f32,
    g: f32,
    big_g: f32,
    dc_g: f32,
}

impl Cem3320Filter {
    pub fn new(sample_rate: f32, cutoff_dispersion: f32) -> Self {
        let mut flt = Self {
            s: [0.0; 4],
            dc_block_state: 0.0,
            sample_rate: sample_rate.max(8000.0),
            cutoff_hz: 2000.0,
            resonance: 0.0,
            drive: 1.0,
            cutoff_dispersion: cutoff_dispersion.clamp(0.95, 1.05),
            g: 0.1,
            big_g: 0.09,
            dc_g: 0.0003,
        };
        flt.update_sample_rate(sample_rate);
        flt.set_params(2000.0, 0.0, 1.0);
        flt
    }

    #[inline]
    pub fn reset(&mut self) {
        self.s = [0.0; 4];
        self.dc_block_state = 0.0;
    }

    #[inline]
    pub fn update_sample_rate(&mut self, sample_rate: f32) {
        let sr = sample_rate.max(8000.0);
        self.sample_rate = sr;
        // 5 Hz 1-pole TPT high-pass coefficient in feedback loop
        let g_hp = (PI * 5.0 / sr).tan();
        self.dc_g = g_hp / (1.0 + g_hp);
        self.set_params(self.cutoff_hz, self.resonance, self.drive);
    }

    #[inline(always)]
    pub fn set_params(&mut self, cutoff_hz: f32, resonance: f32, drive: f32) {
        let fc = (cutoff_hz * self.cutoff_dispersion).clamp(15.0, 0.46 * self.sample_rate);
        self.cutoff_hz = fc;
        self.resonance = resonance.clamp(0.0, 1.0);
        self.drive = drive.clamp(0.25, 4.0);

        // Pre-warped bilinear integrator gain g = tan(pi * fc / fs)
        let g = (PI * fc / self.sample_rate).tan();
        self.g = g;
        self.big_g = g / (1.0 + g);
    }

    /// Processes a single audio sample through the 4-pole ZDF/TPT CEM3320 OTA cascade.
    ///
    /// Mathematical derivation (Vadim Zavalishin TPT):
    /// Each trapezoidal integrator satisfies:
    ///   `v_i = G * (x_i - s_i)`, `y_i = v_i + s_i`, `s_{i,next} = y_i + v_i`
    /// Consequently:
    ///   `y_4 = G^4 * u + S`, where `S = G^3 * s_1 + G^2 * s_2 + G * s_3 + s_4`
    /// And the non-linear differential feedback limiter with 5 Hz AC coupling satisfies:
    ///   `u = x_in - k * tanh(drive * HP_5Hz(y_4))`
    /// Solved algebraically with Newton-Raphson zero-delay feedback iteration.
    #[inline(always)]
    pub fn process_sample(&mut self, input: f32) -> f32 {
        let g1 = self.big_g;
        let g2 = g1 * g1;
        let g3 = g2 * g1;
        let g4 = g2 * g2;

        // Composite historical state contribution S at output of 4th pole
        let big_s = g3 * self.s[0] + g2 * self.s[1] + g1 * self.s[2] + self.s[3];

        // Global feedback gain k in [0.0, 4.5] (self-oscillation threshold at k = 4.0)
        let k = 4.5 * self.resonance;
        let drv = self.drive;
        let inv_drv = 1.0 / drv;

        // 5 Hz TPT high-pass transfer on y4: y_hp = (1 - dc_g) * y4 - dc_block_state
        let hp_gain = 1.0 - self.dc_g;

        // Initial linear ZDF estimate for y4
        let linear_denom = 1.0 + k * g4 * hp_gain;
        let mut y4 = (g4 * input + big_s) / linear_denom;

        // 2-step Newton-Raphson exact non-linear ZDF solution for F(y4) = 0:
        // F(y4) = y4 - G^4 * (input - k * inv_drv * tanh(drv * (hp_gain * y4 - dc_block_state))) - S = 0
        for _ in 0..2 {
            let y_hp = hp_gain * y4 - self.dc_block_state;
            let sat_fb = fast_tanh(drv * y_hp) * inv_drv;
            let u = input - k * sat_fb;
            let f_val = y4 - g4 * u - big_s;
            let df_dy4 = 1.0 + g4 * k * hp_gain * fast_sech2(drv * y_hp);
            y4 -= f_val / df_dy4;
        }

        // Compute final feedback signal u and update 5 Hz DC-blocker TPT state
        let v_hp = self.dc_g * (y4 - self.dc_block_state);
        let y_lp_dc = v_hp + self.dc_block_state;
        self.dc_block_state = y_lp_dc + v_hp;
        let y_hp_final = y4 - y_lp_dc;

        let u_final = fast_tanh(0.85 * input) * 1.176 - k * (fast_tanh(drv * y_hp_final) * inv_drv);

        // Cascade through the 4 OTA trapezoidal integrators
        let v0 = g1 * (u_final - self.s[0]);
        let y0 = v0 + self.s[0];
        self.s[0] = y0 + v0;

        let v1 = g1 * (y0 - self.s[1]);
        let y1 = v1 + self.s[1];
        self.s[1] = y1 + v1;

        let v2 = g1 * (y1 - self.s[2]);
        let y2 = v2 + self.s[2];
        self.s[2] = y2 + v2;

        let v3 = g1 * (y2 - self.s[3]);
        let y3 = v3 + self.s[3];
        self.s[3] = y3 + v3;

        y3
    }
}
